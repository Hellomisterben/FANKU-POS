import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  LayoutDashboard, 
  Hotel, 
  UtensilsCrossed, 
  Waves, 
  Package, 
  Settings, 
  Bell, 
  Search, 
  Sun, 
  Moon, 
  TrendingUp, 
  Users, 
  CreditCard, 
  Wallet, 
  Banknote,
  ChevronDown,
  AlertCircle,
  CheckCircle2,
  Beer,
  Wine,
  Martini,
  Coffee,
  Plus,
  Minus,
  Trash2,
  DoorClosed,
  User,
  Clock,
  Lock,
  LogOut,
  Languages,
  Volume2,
  Smartphone,
  Watch
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// --- UTILS ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- TYPES & ROLES ---
type Role = 'Admin' | 'HotelReception' | 'RestaurantCashier' | 'InventoryManager' | 'Kitchen';

interface UserProfile {
  name: string;
  role: Role;
  avatar: string;
}

interface Message {
  id: string;
  from: string;
  to: Role | 'All';
  text: string;
  timestamp: string;
  isTask?: boolean;
  completed?: boolean;
}

const ROLE_CONFIG: Record<Role, { name: string, tabs: string[], defaultTab: string }> = {
  Admin: { 
    name: 'Administrateur', 
    tabs: ['Dashboard', 'Hotel', 'Restaurant', 'Kitchen', 'Leisure', 'Inventory', 'Settings'],
    defaultTab: 'Dashboard'
  },
  HotelReception: { 
    name: 'Réception Hôtel', 
    tabs: ['Hotel', 'Dashboard'],
    defaultTab: 'Hotel'
  },
  RestaurantCashier: { 
    name: 'Caisse Restaurant', 
    tabs: ['Restaurant', 'Kitchen', 'Leisure', 'Dashboard'],
    defaultTab: 'Restaurant'
  },
  InventoryManager: { 
    name: 'Gestionnaire Stock', 
    tabs: ['Inventory', 'Dashboard'],
    defaultTab: 'Inventory'
  },
  Kitchen: {
    name: 'Cuisine',
    tabs: ['Kitchen', 'Dashboard'],
    defaultTab: 'Kitchen'
  }
};

// --- MOCK DATA ---
const REVENUE_DATA = [
  { name: '08:00', total: 4000 },
  { name: '10:00', total: 3000 },
  { name: '12:00', total: 5000 },
  { name: '14:00', total: 4500 },
  { name: '16:00', total: 6000 },
  { name: '18:00', total: 8000 },
  { name: '20:00', total: 7000 },
];

const PIE_DATA = [
  { name: 'Hotel', value: 45, color: '#6366f1' },
  { name: 'Restaurant', value: 35, color: '#10b981' },
  { name: 'Leisure/Pool', value: 20, color: '#f59e0b' },
];

const INVENTORY_ALERTS = [
  { id: 1, item: 'Soft Drinks', level: 'Low', status: 'warning', count: 12 },
  { id: 2, item: 'Pool Towels', level: 'Critical', status: 'danger', count: 5 },
  { id: 3, item: 'Bed Linens', level: 'Normal', status: 'success', count: 45 },
];

const RECENT_TRANSACTIONS = [
  { id: 'TX-9021', customer: 'John Doe', room: '302', amount: 125.50, type: 'Restaurant', method: 'Card', icon: <UtensilsCrossed size={14} /> },
  { id: 'TX-9022', customer: 'Alice Smith', room: '105', amount: 450.00, type: 'Hotel', method: 'Mobile', icon: <Hotel size={14} /> },
  { id: 'TX-9023', customer: 'Bob Wilson', room: 'N/A', amount: 25.00, type: 'Pool', method: 'Cash', icon: <Waves size={14} /> },
  { id: 'TX-9024', customer: 'Emma Brown', room: '210', amount: 85.20, type: 'Restaurant', method: 'Card', icon: <UtensilsCrossed size={14} /> },
];

const ROLES = ['Fanku Admin', 'Reception', 'Restaurant Staff', 'Leisure Staff'];

// --- HOTEL DATA (12 Rooms) ---
const ROOMS = [
  { id: '101', type: 'Standard', status: 'available', price: 150 },
  { id: '102', type: 'Standard', status: 'occupied', guest: 'John Doe', price: 150 },
  { id: '103', type: 'Deluxe', status: 'expiring', guest: 'Jane Smith', price: 250 },
  { id: '104', type: 'Deluxe', status: 'available', price: 250 },
  { id: '201', type: 'Suite', status: 'occupied', guest: 'Alice Smith', price: 450 },
  { id: '202', type: 'Suite', status: 'available', price: 450 },
  { id: '203', type: 'Standard', status: 'available', price: 150 },
  { id: '204', type: 'Standard', status: 'occupied', guest: 'Bob Wilson', price: 150 },
  { id: '301', type: 'Penthouse', status: 'available', price: 850 },
  { id: '302', type: 'Deluxe', status: 'expiring', guest: 'Charlie Brown', price: 250 },
  { id: '303', type: 'Deluxe', status: 'occupied', guest: 'Emma Brown', price: 250 },
  { id: '304', type: 'Standard', status: 'available', price: 150 },
];

// --- RESTAURANT DATA ---
const MENU_CATEGORIES = ['Food', 'Beer', 'Wine', 'Spirits', 'Soft Drinks'];
const MENU_ITEMS: Record<string, any[]> = {
  Food: [
    { id: 'f1', name: 'Wagyu Burger', price: 28, icon: <UtensilsCrossed size={24}/> },
    { id: 'f2', name: 'Ribeye Steak', price: 45, icon: <UtensilsCrossed size={24}/> },
    { id: 'f3', name: 'Truffle Pasta', price: 32, icon: <UtensilsCrossed size={24}/> },
    { id: 'f4', name: 'Caesar Salad', price: 18, icon: <UtensilsCrossed size={24}/> },
    { id: 'f5', name: 'Club Sandwich', price: 22, icon: <UtensilsCrossed size={24}/> },
    { id: 'f6', name: 'Seafood Risotto', price: 38, icon: <UtensilsCrossed size={24}/> },
  ],
  Beer: [
    { id: 'b1', name: 'Local Draft', price: 8, icon: <Beer size={24}/> },
    { id: 'b2', name: 'Heineken', price: 7, icon: <Beer size={24}/> },
    { id: 'b3', name: 'Corona', price: 7, icon: <Beer size={24}/> },
    { id: 'b4', name: 'Guinness', price: 9, icon: <Beer size={24}/> },
  ],
  Wine: [
    { id: 'w1', name: 'House Red (Glass)', price: 12, icon: <Wine size={24}/> },
    { id: 'w2', name: 'Chardonnay (Glass)', price: 14, icon: <Wine size={24}/> },
    { id: 'w3', name: 'Merlot Bottle', price: 65, icon: <Wine size={24}/> },
    { id: 'w4', name: 'Champagne', price: 120, icon: <Wine size={24}/> },
  ],
  Spirits: [
    { id: 's1', name: 'Don Julio Tequila', price: 16, icon: <Martini size={24}/> },
    { id: 's2', name: 'Macallan 12 Whisky', price: 22, icon: <Martini size={24}/> },
    { id: 's3', name: 'Grey Goose Vodka', price: 15, icon: <Martini size={24}/> },
    { id: 's4', name: 'Hendricks Gin', price: 14, icon: <Martini size={24}/> },
    { id: 's5', name: 'Patron Silver', price: 18, icon: <Martini size={24}/> },
    { id: 's6', name: 'Blue Label', price: 45, icon: <Martini size={24}/> },
  ],
  'Soft Drinks': [
    { id: 'sd1', name: 'Coca Cola', price: 5, icon: <Coffee size={24}/> },
    { id: 'sd2', name: 'Sparkling Water', price: 6, icon: <Coffee size={24}/> },
    { id: 'sd3', name: 'Fresh Orange Juice', price: 8, icon: <Coffee size={24}/> },
  ]
};

// --- LEISURE DATA ---
const LEISURE_ITEMS = [
  { id: 'l1', name: 'Day Pool Pass', price: 25, icon: <Waves size={24}/> },
  { id: 'l2', name: 'Cabana Rental (Half Day)', price: 150, icon: <Sun size={24}/> },
  { id: 'l3', name: 'Cabana Rental (Full Day)', price: 250, icon: <Sun size={24}/> },
  { id: 'l4', name: 'Spa Massage (60 min)', price: 120, icon: <Waves size={24}/> },
  { id: 'l5', name: 'Towel Rental', price: 5, icon: <Package size={24}/> },
];

// --- INVENTORY DATA ---
const INVENTORY_ITEMS = [
  { id: 'inv1', name: 'Heineken', category: 'Beer', stock: 145, minStock: 50, status: 'Good' },
  { id: 'inv2', name: 'Wagyu Beef', category: 'Food', stock: 12, minStock: 20, status: 'Low' },
  { id: 'inv3', name: 'Pool Towels', category: 'Leisure', stock: 5, minStock: 30, status: 'Critical' },
  { id: 'inv4', name: 'Coca Cola', category: 'Soft Drinks', stock: 210, minStock: 100, status: 'Good' },
  { id: 'inv5', name: 'Macallan 12', category: 'Spirits', stock: 8, minStock: 5, status: 'Good' },
  { id: 'inv6', name: 'Bed Linens', category: 'Hotel', stock: 45, minStock: 40, status: 'Low' },
];

// --- MAIN APP COMPONENT ---
export default function App() {
  const { t } = useTranslation();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<any | null>(null);
  const [logoUrl, setLogoUrl] = useState('https://lh3.googleusercontent.com/d/1BOXBJgkRy536WRiAzN8FlUqMd58yt3wm');
  const [menuItems, setMenuItems] = useState<Record<string, any[]>>(MENU_ITEMS);
  const [inventoryItems, setInventoryItems] = useState(INVENTORY_ITEMS);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', from: 'Admin', to: 'All', text: 'Bienvenue sur le nouveau système POS !', timestamp: '08:00' },
    { id: '2', from: 'Admin', to: 'HotelReception', text: 'Vérifiez la chambre 103, le client part à 11h.', timestamp: '09:15', isTask: true },
  ]);
  const [kitchenOrders, setKitchenOrders] = useState<any[]>([
    { id: 'O-101', table: '12', items: [{ name: 'Wagyu Burger', quantity: 2 }, { name: 'Coca Cola', quantity: 2 }], status: 'pending', timestamp: '20:15' },
    { id: 'O-102', table: '05', items: [{ name: 'Truffle Pasta', quantity: 1 }], status: 'cooking', timestamp: '20:20' },
  ]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  const handleLogin = (role: Role, username: string) => {
    setUser({
      name: username,
      role: role,
      avatar: role.substring(0, 2).toUpperCase()
    });
    
    setActiveTab(ROLE_CONFIG[role].defaultTab);
  };

  const handleLogout = () => {
    setUser(null);
    setIsUserMenuOpen(false);
    setIsChatOpen(false);
  };

  const addMessage = (text: string, to: Role | 'All' = 'All', isTask = false) => {
    if (!user) return;
    const newMessage: Message = {
      id: Date.now().toString(),
      from: user.name,
      to,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isTask
    };
    setMessages([...messages, newMessage]);
    
    // Simulate notification to staff (smartwatch/beeper)
    if (to !== 'All') {
      console.log(`[STAFF NOTIFICATION] Sent to ${to}: ${text}`);
    }
  };

  const addKitchenOrder = (order: any) => {
    setKitchenOrders(prev => [...prev, { ...order, status: 'pending', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    addMessage(t('new_order'), 'Kitchen', true);
  };

  if (!user) {
    return <LoginScreen onLogin={handleLogin} isDarkMode={isDarkMode} toggleTheme={toggleTheme} logoUrl={logoUrl} />;
  }

  const allowedTabs = ROLE_CONFIG[user.role].tabs;

  // Render content based on active tab
  const renderContent = () => {
    switch (activeTab) {
      case 'Dashboard':
        return <DashboardView role={user.role} logoUrl={logoUrl} />;
      case 'Hotel':
        return <HotelView onRoomClick={(room) => setSelectedRoom(room)} />;
      case 'Restaurant':
        return <RestaurantView onOrderSubmit={addKitchenOrder} menuItems={menuItems} inventoryItems={inventoryItems} />;
      case 'Kitchen':
        return <KitchenView orders={kitchenOrders} setOrders={setKitchenOrders} />;
      case 'Leisure':
        return <LeisureView />;
      case 'Inventory':
        return <InventoryView items={inventoryItems} setItems={setInventoryItems} menuItems={menuItems} setMenuItems={setMenuItems} />;
      case 'Settings':
        return <SettingsView logoUrl={logoUrl} setLogoUrl={setLogoUrl} />;
      default:
        return <DashboardView role={user.role} logoUrl={logoUrl} />;
    }
  };

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background text-foreground transition-colors duration-300">
      {/* Sidebar - Hidden on small mobile, but we'll use a responsive approach */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} role={user.role} logoUrl={logoUrl} messagesCount={messages.length} userName={user.name} userRole={user.role} onChatOpen={() => setIsChatOpen(true)} />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header */}
        <header className="h-20 border-b border-border bg-card flex items-center justify-between px-4 md:px-8 shrink-0 z-10">
          {/* Logo in Header (Mobile only) */}
          <div className="md:hidden flex items-center gap-2 mr-4">
            <div className="w-10 h-10 rounded-xl overflow-hidden flex items-center justify-center shadow-sm bg-white/80 dark:bg-white/10 backdrop-blur-md p-1">
              <img 
                src={logoUrl} 
                alt="Fanku Hotel Logo" 
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          <div className="flex-1 max-w-xl hidden sm:block">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors" size={20} />
              <input 
                type="text" 
                placeholder={t('search_placeholder')} 
                className="w-full bg-muted border-none rounded-2xl py-3 pl-12 pr-4 text-sm focus:ring-2 focus:ring-primary/20 transition-all outline-none"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 md:gap-4 ml-auto">
            <button 
              onClick={toggleTheme}
              className="p-2.5 md:p-3 rounded-xl bg-muted hover:bg-border transition-colors text-foreground/80 hover:text-foreground active:scale-95"
              aria-label="Toggle Theme"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            <LanguageSelector />

            {user.role === 'Admin' && (
              <div className="hidden xl:flex items-center gap-2 bg-muted p-1.5 rounded-xl">
                <button onClick={() => setActiveTab('Dashboard')} className={cn("px-3 py-1.5 rounded-lg text-xs font-bold transition-all", activeTab === 'Dashboard' ? "bg-card shadow-sm" : "opacity-60")}>{t('global')}</button>
                <button onClick={() => setActiveTab('Hotel')} className={cn("px-3 py-1.5 rounded-lg text-xs font-bold transition-all", activeTab === 'Hotel' ? "bg-card shadow-sm" : "opacity-60")}>{t('hotel_tab')}</button>
                <button onClick={() => setActiveTab('Restaurant')} className={cn("px-3 py-1.5 rounded-lg text-xs font-bold transition-all", activeTab === 'Restaurant' ? "bg-card shadow-sm" : "opacity-60")}>{t('resto_tab')}</button>
              </div>
            )}

            <div className="h-8 w-[1px] bg-border mx-1 md:mx-2" />

            <div className="relative">
              <button 
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-2 md:gap-3 pl-1 md:pl-2 pr-1 md:pr-2 py-1.5 rounded-xl hover:bg-muted transition-colors active:scale-95"
              >
                <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white font-bold text-xs md:text-sm shadow-md">
                  {user.avatar}
                </div>
                <div className="text-left hidden md:block">
                  <p className="text-sm font-bold leading-none">{user.name}</p>
                  <p className="text-xs opacity-60 mt-1">{user.role}</p>
                </div>
                <ChevronDown size={14} className={cn("transition-transform ml-1", isUserMenuOpen && "rotate-180")} />
              </button>

              <AnimatePresence>
                {isUserMenuOpen && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute right-0 mt-2 w-48 bg-card border border-border rounded-xl shadow-xl z-50 py-2 overflow-hidden"
                  >
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-5 py-3 text-sm hover:bg-red-500/10 text-red-500 transition-colors flex items-center gap-3 font-bold"
                    >
                      <LogOut size={16} />
                      {t('logout')}
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        {/* Dynamic Content */}
        <div className="flex-1 overflow-hidden relative bg-background">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 overflow-y-auto"
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Footer */}
        <footer className="h-14 border-t border-border bg-card/30 backdrop-blur-sm flex items-center justify-between px-4 md:px-8 shrink-0 z-10 text-[10px] uppercase tracking-[0.2em] opacity-50 font-black">
          <div className="flex items-center gap-5">
            <div className="w-7 h-7 rounded-lg overflow-hidden flex items-center justify-center bg-white/80 dark:bg-white/10 p-1 shadow-sm">
              <img src={logoUrl} alt="Logo" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
            </div>
            <span className="hover:text-primary transition-colors cursor-default">© 2026 POS</span>
          </div>
          <div className="flex items-center gap-4 hidden sm:flex">
            <span>v2.4.0-stable</span>
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
              <span>System Online</span>
            </div>
          </div>
        </footer>
      </main>

      {/* Mobile Bottom Nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-card border-t border-border flex items-center justify-around z-50 px-2">
        {allowedTabs.slice(0, 5).map(tab => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              activeTab === tab ? "text-primary" : "text-muted-foreground"
            )}
          >
            {tab === 'Dashboard' && <LayoutDashboard size={20} />}
            {tab === 'Hotel' && <Hotel size={20} />}
            {tab === 'Restaurant' && <UtensilsCrossed size={20} />}
            {tab === 'Kitchen' && <Coffee size={20} />}
            {tab === 'Inventory' && <Package size={20} />}
            <span className="text-[10px] font-bold">{t(tab.toLowerCase())}</span>
          </button>
        ))}
      </div>

      {/* Modals */}
      <AnimatePresence>
        {isChatOpen && (
          <ChatModal 
            messages={messages} 
            onClose={() => setIsChatOpen(false)} 
            onSendMessage={addMessage}
            currentUser={user}
          />
        )}
        {selectedRoom && (
          <RoomModal 
            room={selectedRoom} 
            onClose={() => setSelectedRoom(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// --- CHAT MODAL ---
function ChatModal({ messages, onClose, onSendMessage, currentUser }: { messages: Message[], onClose: () => void, onSendMessage: (text: string, to: Role | 'All', isTask: boolean) => void, currentUser: UserProfile }) {
  const { t } = useTranslation();
  const [inputText, setInputText] = useState('');
  const [targetRole, setTargetRole] = useState<Role | 'All'>('All');
  const [isTask, setIsTask] = useState(false);

  const handleSend = () => {
    if (!inputText.trim()) return;
    onSendMessage(inputText, targetRole, isTask);
    setInputText('');
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100] flex items-center justify-end p-6"
      onClick={onClose}
    >
      <motion.div 
        initial={{ x: 100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: 100, opacity: 0 }}
        className="w-full max-w-md h-full bg-card border border-border rounded-3xl shadow-2xl flex flex-col overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-6 border-b border-border flex items-center justify-between bg-primary text-primary-foreground">
          <div className="flex items-center gap-3">
            <Bell size={24} />
            <h3 className="font-bold text-lg">{t('internal_communication')}</h3>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
            <Plus size={24} className="rotate-45" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map(msg => (
            <div key={msg.id} className={cn("flex flex-col", msg.from === currentUser.name ? "items-end" : "items-start")}>
              <div className={cn(
                "max-w-[85%] p-4 rounded-2xl shadow-sm",
                msg.from === currentUser.name ? "bg-primary text-primary-foreground" : "bg-muted",
                msg.isTask && "border-2 border-yellow-500/50"
              )}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-black uppercase tracking-widest opacity-70">{msg.from} → {msg.to}</span>
                  {msg.isTask && <div className="w-2 h-2 bg-yellow-500 rounded-full" />}
                </div>
                <p className="text-sm font-medium">{msg.text}</p>
                <p className="text-[10px] opacity-50 mt-2 text-right">{msg.timestamp}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="p-6 border-t border-border bg-muted/30 space-y-4">
          <div className="flex gap-2">
            <select 
              value={targetRole} 
              onChange={(e) => setTargetRole(e.target.value as any)}
              className="bg-card border border-border rounded-xl px-3 py-2 text-xs font-bold outline-none"
            >
              <option value="All">{t('all')}</option>
              <option value="Admin">{t('admin')}</option>
              <option value="HotelReception">{t('reception')}</option>
              <option value="RestaurantCashier">{t('resto_tab')}</option>
              <option value="InventoryManager">{t('stock')}</option>
            </select>
            <button 
              onClick={() => setIsTask(!isTask)}
              className={cn("px-3 py-2 rounded-xl text-xs font-bold transition-colors", isTask ? "bg-yellow-500 text-white" : "bg-card border border-border")}
            >
              {t('task')}
            </button>
          </div>
          <div className="flex gap-2">
            <input 
              type="text" 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={t('write_message')}
              className="flex-1 bg-card border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/20"
            />
            <button 
              onClick={handleSend}
              className="bg-primary text-primary-foreground p-3 rounded-xl shadow-lg shadow-primary/20 active:scale-95 transition-all"
            >
              <TrendingUp size={20} className="rotate-90" />
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// --- ROOM MODAL ---
function RoomModal({ room, onClose }: { room: any, onClose: () => void }) {
  const { t } = useTranslation();
  const isOccupied = room.status !== 'available';
  
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md z-[100] flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-2xl bg-card border border-border rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className={cn(
          "p-8 text-white flex justify-between items-center",
          room.status === 'available' ? "bg-red-500" : room.status === 'occupied' ? "bg-green-500" : "bg-yellow-500"
        )}>
          <div>
            <h2 className="text-4xl font-black">{t('room')} {room.id}</h2>
            <p className="font-bold opacity-80 uppercase tracking-widest mt-1">{t(room.type.toLowerCase())} • {room.status === 'available' ? t('available') : t('occupied')}</p>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-white/20 rounded-full transition-colors">
            <Plus size={32} className="rotate-45" />
          </button>
        </div>

        <div className="p-10 grid grid-cols-1 md:grid-cols-2 gap-10">
          {isOccupied ? (
            <>
              <div className="space-y-6">
                <h3 className="text-xl font-black border-b border-border pb-2">{t('client_details')}</h3>
                <div className="space-y-4">
                  <InfoItem icon={<User size={18} />} label={t('full_name')} value={room.guest} />
                  <InfoItem icon={<CreditCard size={18} />} label={t('id_passport')} value="AB1234567" />
                  <InfoItem icon={<Clock size={18} />} label={t('check_in')} value="12 Mars 2026, 14:30" />
                  <InfoItem icon={<Clock size={18} />} label={t('check_out_planned')} value="15 Mars 2026, 11:00" />
                </div>
              </div>
              <div className="space-y-6">
                <h3 className="text-xl font-black border-b border-border pb-2">{t('billing')}</h3>
                <div className="bg-muted p-6 rounded-3xl space-y-3">
                  <div className="flex justify-between font-bold"><span>{t('nights_count')} (3)</span><span>$450.00</span></div>
                  <div className="flex justify-between font-bold"><span>{t('restaurant')}</span><span>$85.50</span></div>
                  <div className="flex justify-between font-bold"><span>{t('leisure')}</span><span>$20.00</span></div>
                  <div className="pt-3 border-t border-border flex justify-between text-2xl font-black text-primary">
                    <span>{t('total')}</span>
                    <span>$555.50</span>
                  </div>
                </div>
                <button className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-black shadow-xl shadow-primary/20 active:scale-95 transition-all">
                  {t('check_out')}
                </button>
              </div>
            </>
          ) : (
            <>
              <div className="space-y-6">
                <h3 className="text-xl font-black border-b border-border pb-2">{t('client_details')}</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase opacity-60">{t('guest_name')}</label>
                    <input type="text" placeholder={t('guest_name_placeholder')} className="w-full bg-muted border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary/20 outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase opacity-60">{t('phone')}</label>
                    <input type="tel" placeholder={t('phone_placeholder')} className="w-full bg-muted border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary/20 outline-none" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase opacity-60">{t('nights')}</label>
                      <input type="number" defaultValue={1} className="w-full bg-muted border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary/20 outline-none" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase opacity-60">{t('people')}</label>
                      <input type="number" defaultValue={1} className="w-full bg-muted border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary/20 outline-none" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="space-y-6 flex flex-col justify-end">
                <div className="bg-primary/5 p-6 rounded-3xl border border-primary/10">
                  <p className="text-sm font-bold opacity-60 mb-2">{t('stay_estimation')}</p>
                  <p className="text-4xl font-black text-primary">${room.price}<span className="text-lg opacity-50 font-normal">.00</span></p>
                </div>
                <button className="w-full py-4 bg-red-500 text-white rounded-2xl font-black shadow-xl shadow-red-500/20 active:scale-95 transition-all">
                  {t('confirm_occupation_btn')}
                </button>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

function InfoItem({ icon, label, value }: { icon: React.ReactNode, label: string, value: string }) {
  return (
    <div className="flex items-center gap-4">
      <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center text-muted-foreground">
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-black uppercase opacity-50 leading-none mb-1">{label}</p>
        <p className="font-bold text-sm">{value}</p>
      </div>
    </div>
  );
}

// --- LOGIN SCREEN ---
function LoginScreen({ onLogin, isDarkMode, toggleTheme, logoUrl }: { onLogin: (role: Role, username: string) => void, isDarkMode: boolean, toggleTheme: () => void, logoUrl: string }) {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground relative overflow-hidden p-4">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-indigo-500/10 blur-3xl" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-emerald-500/10 blur-3xl" />
      </div>

      <div className="absolute top-4 md:top-8 right-4 md:right-8 flex gap-2 z-20">
        <LanguageSelector />
        <button 
          onClick={toggleTheme}
          className="p-3 rounded-xl bg-card border border-border hover:bg-muted transition-colors"
        >
          {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-card border border-border rounded-3xl shadow-2xl p-6 md:p-8 z-10 relative"
      >
        <div className="flex flex-col items-center mb-6 md:mb-8">
          <div className="w-24 h-24 md:w-32 md:h-32 rounded-[2rem] overflow-hidden flex items-center justify-center shadow-2xl bg-white p-4 mb-6 md:mb-8 transition-all duration-700 hover:rotate-3 hover:scale-110">
            <img 
              src={logoUrl} 
              alt="Logo" 
              className="w-full h-full object-contain drop-shadow-md"
              referrerPolicy="no-referrer"
            />
          </div>
          <h1 className="text-xl md:text-2xl font-black text-center">{t('app_name')}</h1>
          <p className="text-muted-foreground text-xs md:text-sm mt-2 text-center">{t('login_title')}</p>
        </div>

        <div className="space-y-2 md:space-y-3">
          <LoginButton role="Admin" icon={<Lock size={18} />} title={t('admin')} desc={t('admin_desc')} onClick={() => onLogin('Admin', 'Admin')} />
          <LoginButton role="HotelReception" icon={<Hotel size={18} />} title={t('reception')} desc={t('reception_desc')} onClick={() => onLogin('HotelReception', 'Reception')} />
          <LoginButton role="RestaurantCashier" icon={<UtensilsCrossed size={18} />} title={t('cashier')} desc={t('cashier_desc')} onClick={() => onLogin('RestaurantCashier', 'Cashier')} />
          <LoginButton role="InventoryManager" icon={<Package size={18} />} title={t('stock_manager')} desc={t('stock_desc')} onClick={() => onLogin('InventoryManager', 'Manager')} />
          <LoginButton role="Kitchen" icon={<Coffee size={18} />} title={t('kitchen_view')} desc={t('kitchen_view_desc')} onClick={() => onLogin('Kitchen', 'Kitchen')} />
        </div>
      </motion.div>
    </div>
  );
}

function LoginButton({ role, icon, title, desc, onClick }: { role: Role, icon: React.ReactNode, title: string, desc: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className="w-full flex items-center gap-4 p-4 rounded-2xl border border-border bg-background hover:bg-muted hover:border-primary/30 transition-all active:scale-95 group text-left"
    >
      <div className="w-12 h-12 rounded-xl bg-primary/5 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
        {icon}
      </div>
      <div>
        <h3 className="font-bold text-sm">{title}</h3>
        <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>
      </div>
    </button>
  );
}

// --- SIDEBAR COMPONENT ---
function Sidebar({ activeTab, setActiveTab, role, logoUrl, messagesCount, userName, userRole, onChatOpen }: { 
  activeTab: string, 
  setActiveTab: (t: string) => void, 
  role: Role, 
  logoUrl: string,
  messagesCount: number,
  userName: string,
  userRole: string,
  onChatOpen: () => void
}) {
  const { t } = useTranslation();
  const allowedTabs = ROLE_CONFIG[role].tabs;

  return (
    <aside className="hidden md:flex w-64 border-r border-border bg-card flex-col shrink-0 z-20">
      <div className="p-6 flex items-center gap-3">
        <div className="w-16 h-16 rounded-2xl overflow-hidden flex items-center justify-center shadow-inner bg-white/50 dark:bg-white/10 backdrop-blur-sm p-1.5 transition-all duration-500 hover:bg-white dark:hover:bg-white/20 group">
          <img 
            src={logoUrl} 
            alt="Logo" 
            className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-110"
            referrerPolicy="no-referrer"
          />
        </div>
        <div>
          <h1 className="font-bold text-lg leading-tight">POS</h1>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-[10px] uppercase tracking-wider opacity-60 font-semibold">{t('online_synced')}</span>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-2 overflow-y-auto">
        {allowedTabs.includes('Dashboard') && <NavItem icon={<LayoutDashboard size={22} />} label={t('dashboard')} active={activeTab === 'Dashboard'} onClick={() => setActiveTab('Dashboard')} />}
        {allowedTabs.includes('Hotel') && <NavItem icon={<Hotel size={22} />} label={t('hotel')} active={activeTab === 'Hotel'} onClick={() => setActiveTab('Hotel')} />}
        {allowedTabs.includes('Restaurant') && <NavItem icon={<UtensilsCrossed size={22} />} label={t('restaurant')} active={activeTab === 'Restaurant'} onClick={() => setActiveTab('Restaurant')} />}
        {allowedTabs.includes('Kitchen') && <NavItem icon={<Coffee size={22} />} label={t('kitchen_view')} active={activeTab === 'Kitchen'} onClick={() => setActiveTab('Kitchen')} />}
        {allowedTabs.includes('Leisure') && <NavItem icon={<Waves size={22} />} label={t('leisure')} active={activeTab === 'Leisure'} onClick={() => setActiveTab('Leisure')} />}
        {allowedTabs.includes('Inventory') && <NavItem icon={<Package size={22} />} label={t('inventory')} active={activeTab === 'Inventory'} onClick={() => setActiveTab('Inventory')} />}
        {allowedTabs.includes('Settings') && <NavItem icon={<Settings size={22} />} label={t('settings')} active={activeTab === 'Settings'} onClick={() => setActiveTab('Settings')} />}
      </nav>

      <div className="p-4 mt-auto space-y-2">
        <button 
          onClick={onChatOpen}
          className="w-full flex items-center gap-3 p-3 rounded-xl bg-primary/10 text-primary hover:bg-primary/20 transition-colors font-bold text-sm"
        >
          <Bell size={18} />
          {t('messages_tasks')}
          {messagesCount > 0 && <span className="ml-auto bg-primary text-white text-[10px] px-1.5 py-0.5 rounded-full">{messagesCount}</span>}
        </button>
        
        <div className="bg-muted rounded-xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Users size={20} className="text-primary" />
          </div>
          <div className="overflow-hidden">
            <p className="text-sm font-semibold truncate">{userName}</p>
            <p className="text-xs opacity-60">{userRole}</p>
          </div>
        </div>
      </div>
    </aside>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all duration-300 font-bold text-sm group relative overflow-hidden",
        active 
          ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
          : "text-muted-foreground hover:bg-muted hover:text-foreground"
      )}
    >
      <div className={cn("transition-transform duration-300 group-hover:scale-110", active ? "scale-110" : "scale-100")}>
        {icon}
      </div>
      <span className="relative z-10">{label}</span>
      {active && (
        <motion.div 
          layoutId="activeTab"
          className="absolute inset-0 bg-gradient-to-r from-primary to-primary/80 -z-10"
        />
      )}
    </button>
  );
}

function StatusCard({ label, value }: { label: string, value: string }) {
  return (
    <div className="p-4 bg-card rounded-2xl border border-border">
      <p className="text-xs font-black uppercase opacity-50 mb-1">{label}</p>
      <p className="font-bold">{value}</p>
    </div>
  );
}

function DashboardView({ role, logoUrl }: { role?: Role, logoUrl: string }) {
  const { t } = useTranslation();

  return (
    <div className="p-8 space-y-8">
      {/* Welcome Banner */}
      <div className="card p-8 bg-gradient-to-br from-primary/20 via-primary/5 to-transparent border-none flex flex-col md:flex-row items-center gap-10 relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -mr-32 -mt-32 blur-3xl transition-all duration-1000 group-hover:bg-primary/10" />
        <div className="w-32 h-32 md:w-40 md:h-40 rounded-[2.5rem] overflow-hidden flex items-center justify-center shadow-2xl bg-white p-4 shrink-0 transition-all duration-700 hover:scale-105 hover:-rotate-3">
          <img src={logoUrl} alt="Logo" className="w-full h-full object-contain drop-shadow-xl" referrerPolicy="no-referrer" />
        </div>
        <div className="text-center md:text-left relative z-10">
          <h2 className="text-3xl md:text-4xl font-black mb-3 tracking-tight">Bienvenue sur POS</h2>
          <p className="text-muted-foreground max-w-lg text-lg leading-relaxed">Votre plateforme unifiée pour la gestion hôtelière, la restauration et les services de loisirs. Tout ce dont vous avez besoin, au même endroit.</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title={t('global_revenue')} value="$24,500.00" trend="+12.5%" icon={<TrendingUp size={24} />} color="indigo" />
        <StatCard title={t('home_occupancy')} value="84%" trend="+4.2%" icon={<Hotel size={24} />} color="emerald" />
        <StatCard title={t('returns_order')} value="142" trend="+18.3%" icon={<UtensilsCrossed size={24} />} color="amber" />
        <StatCard title={t('pool_passes_sold')} value="56" trend="-2.4%" icon={<Waves size={24} />} color="sky" />
      </div>

      {/* Charts & Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 card p-6 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-lg">{t('revenue_overview')}</h3>
            <select className="bg-muted border-none rounded-xl text-sm font-semibold px-4 py-2 outline-none cursor-pointer hover:bg-border transition-colors">
              <option>{t('last_24_hours')}</option>
              <option>{t('last_7_days')}</option>
              <option>{t('last_month')}</option>
            </select>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={REVENUE_DATA}>
                <defs>
                  <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} dx={-10} />
                <Tooltip contentStyle={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', borderRadius: '12px', fontSize: '14px', fontWeight: 'bold' }} />
                <Area type="monotone" dataKey="total" stroke="#6366f1" strokeWidth={4} fillOpacity={1} fill="url(#colorTotal)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-6 flex flex-col">
          <h3 className="font-bold text-lg mb-6">{t('revenue_split')}</h3>
          <div className="flex-1 flex flex-col items-center justify-center">
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={PIE_DATA} cx="50%" cy="50%" innerRadius={70} outerRadius={90} paddingAngle={5} dataKey="value">
                    {PIE_DATA.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '12px', fontWeight: 'bold', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-full space-y-4 mt-6">
              {PIE_DATA.map((item) => (
                <div key={item.name} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded-full shadow-inner" style={{ backgroundColor: item.color }} />
                    <span className="font-medium opacity-80">{t(item.name.toLowerCase().replace(/\s+/g, '_'))}</span>
                  </div>
                  <span className="font-bold text-base">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: Inventory & Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="card p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-lg">{t('inventory_alerts')}</h3>
            <AlertCircle size={20} className="text-amber-500" />
          </div>
          <div className="space-y-4">
            {INVENTORY_ALERTS.map((alert) => (
              <div key={alert.id} className="flex items-center justify-between p-4 rounded-2xl bg-muted/50 border border-border/50 hover:bg-muted transition-colors cursor-pointer active:scale-[0.98]">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center shadow-sm",
                    alert.status === 'danger' ? "bg-red-500/10 text-red-500" :
                    alert.status === 'warning' ? "bg-amber-500/10 text-amber-500" :
                    "bg-emerald-500/10 text-emerald-500"
                  )}>
                    {alert.status === 'success' ? <CheckCircle2 size={24} /> : <AlertCircle size={24} />}
                  </div>
                  <div>
                    <p className="text-base font-bold">{t(alert.item.toLowerCase().replace(/ /g, '_'))}</p>
                    <p className="text-sm opacity-60">{alert.count} {t('units_remaining')}</p>
                  </div>
                </div>
                <span className={cn(
                  "text-xs font-bold uppercase px-3 py-1.5 rounded-full",
                  alert.status === 'danger' ? "bg-red-500 text-white" :
                  alert.status === 'warning' ? "bg-amber-500 text-white" :
                  "bg-emerald-500 text-white"
                )}>
                  {t(alert.level.toLowerCase())}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-2 card p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-lg">{t('unified_billing')}</h3>
            <div className="flex gap-2">
              <button className="p-2.5 rounded-xl bg-muted hover:bg-border transition-colors active:scale-95"><CreditCard size={18} /></button>
              <button className="p-2.5 rounded-xl bg-muted hover:bg-border transition-colors active:scale-95"><Wallet size={18} /></button>
              <button className="p-2.5 rounded-xl bg-muted hover:bg-border transition-colors active:scale-95"><Banknote size={18} /></button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider opacity-50 border-b border-border">
                  <th className="pb-4 font-semibold px-2">{t('transaction_id')}</th>
                  <th className="pb-4 font-semibold px-2">{t('customer_room')}</th>
                  <th className="pb-4 font-semibold px-2">{t('type')}</th>
                  <th className="pb-4 font-semibold px-2">{t('amount')}</th>
                  <th className="pb-4 font-semibold px-2">{t('method')}</th>
                  <th className="pb-4 font-semibold text-right px-2">{t('action')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {RECENT_TRANSACTIONS.map((tx) => (
                  <tr key={tx.id} className="text-sm group hover:bg-muted/50 transition-colors cursor-pointer">
                    <td className="py-4 px-2 font-mono text-xs font-medium">{tx.id}</td>
                    <td className="py-4 px-2">
                      <p className="font-bold text-base">{tx.customer}</p>
                      <p className="text-xs opacity-60 mt-0.5">{t('room')} {tx.room}</p>
                    </td>
                    <td className="py-4 px-2">
                      <span className={cn(
                        "inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold uppercase",
                        tx.type === 'Hotel' ? "bg-indigo-500/10 text-indigo-500" :
                        tx.type === 'Restaurant' ? "bg-emerald-500/10 text-emerald-500" :
                        "bg-sky-500/10 text-sky-500"
                      )}>
                        {tx.icon}
                        {t(tx.type.toLowerCase())}
                      </span>
                    </td>
                    <td className="py-4 px-2 font-bold text-base">${tx.amount.toFixed(2)}</td>
                    <td className="py-4 px-2 text-sm opacity-70 font-medium">{t(tx.method.toLowerCase())}</td>
                    <td className="py-4 px-2 text-right">
                      <button className="text-sm font-bold text-primary hover:underline px-3 py-1.5 rounded-lg hover:bg-primary/5 transition-colors active:scale-95">{t('view_receipt')}</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

function HotelView({ onRoomClick }: { onRoomClick: (room: any) => void }) {
  const { t } = useTranslation();
  return (
    <div className="p-8 h-full flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold">{t('room_management')}</h2>
          <p className="text-muted-foreground mt-1">{t('room_management_desc')}</p>
        </div>
        <div className="flex gap-4 bg-card p-3 rounded-2xl border border-border shadow-sm">
          <div className="flex items-center gap-2 text-sm font-bold"><div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div> {t('available')} ({t('red')})</div>
          <div className="flex items-center gap-2 text-sm font-bold"><div className="w-3 h-3 rounded-full bg-green-500"></div> {t('occupied')} ({t('green')})</div>
          <div className="flex items-center gap-2 text-sm font-bold"><div className="w-3 h-3 rounded-full bg-yellow-500"></div> {t('expiration')} ({t('yellow')})</div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {ROOMS.map((room) => (
          <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            key={room.id}
            onClick={() => onRoomClick(room)}
            className={cn(
              "card p-6 text-left transition-all duration-300 border-l-8 shadow-md relative overflow-hidden",
              room.status === 'available' ? "border-l-red-500 hover:shadow-red-500/20" :
              room.status === 'occupied' ? "border-l-green-500 hover:shadow-green-500/20" :
              "border-l-yellow-500 hover:shadow-yellow-500/20"
            )}
          >
            {/* Background glow based on status */}
            <div className={cn(
              "absolute -right-10 -top-10 w-32 h-32 rounded-full blur-3xl opacity-20",
              room.status === 'available' ? "bg-red-500" :
              room.status === 'occupied' ? "bg-green-500" :
              "bg-yellow-500"
            )} />

            <div className="flex justify-between items-start mb-4 relative z-10">
              <div className="flex items-center gap-3">
                <DoorClosed size={28} className={cn(
                  room.status === 'available' ? "text-red-500" :
                  room.status === 'occupied' ? "text-green-500" :
                  "text-yellow-500"
                )} />
                <h3 className="text-3xl font-black">{room.id}</h3>
              </div>
              <span className="text-xs font-bold opacity-80 bg-muted px-2.5 py-1 rounded-md">{t(room.type.toLowerCase())}</span>
            </div>
            
            <div className="space-y-3 relative z-10">
              {room.status === 'occupied' ? (
                <div className="flex items-center gap-2 text-sm font-bold text-green-600 dark:text-green-400 bg-green-500/10 p-2 rounded-lg">
                  <User size={16} />
                  {room.guest}
                </div>
              ) : room.status === 'expiring' ? (
                <div className="flex items-center gap-2 text-sm font-bold text-yellow-600 dark:text-yellow-400 bg-yellow-500/10 p-2 rounded-lg">
                  <Clock size={16} />
                  {t('imminent_departure')} ({room.guest})
                </div>
              ) : (
                <div className="flex items-center gap-2 text-sm font-bold text-red-600 dark:text-red-400 bg-red-500/10 p-2 rounded-lg">
                  <CheckCircle2 size={16} />
                  {t('available_room')}
                </div>
              )}
              
              <div className="pt-4 mt-4 border-t border-border flex justify-between items-center">
                <span className="text-xl font-black">${room.price}<span className="text-xs opacity-50 font-normal">/{t('night')}</span></span>
                <span className={cn(
                  "text-[10px] font-black uppercase tracking-wider px-2 py-1 rounded-full text-white",
                  room.status === 'available' ? "bg-red-500" :
                  room.status === 'occupied' ? "bg-green-500" :
                  "bg-yellow-500 text-yellow-950"
                )}>
                  {t(room.status)}
                </span>
              </div>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}

function RestaurantView({ onOrderSubmit, menuItems, inventoryItems }: { onOrderSubmit: (order: any) => void, menuItems: Record<string, any[]>, inventoryItems: any[] }) {
  const { t } = useTranslation();
  const [activeCategory, setActiveCategory] = useState(MENU_CATEGORIES[0]);
  const [cart, setCart] = useState<any[]>([]);

  const addToCart = (item: any) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQ = item.quantity + delta;
        return newQ > 0 ? { ...item, quantity: newQ } : item;
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const handleOrder = () => {
    if (cart.length === 0) return;
    onOrderSubmit({
      id: `O-${Math.floor(Math.random() * 1000)}`,
      table: Math.floor(Math.random() * 20 + 1).toString(),
      items: cart,
    });
    setCart([]);
    alert(t('notification_sent'));
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.1; // 10% tax
  const total = subtotal + tax;

  // Mock data for restaurant stats
  const RESTAURANT_STATS = [
    { name: 'Food', sales: 1200 },
    { name: 'Beer', sales: 450 },
    { name: 'Wine', sales: 800 },
    { name: 'Spirits', sales: 600 },
  ];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Top POS Area */}
      <div className="flex flex-col lg:flex-row flex-1 overflow-hidden min-h-[60vh]">
        {/* Menu Section */}
        <div className="flex-1 p-6 flex flex-col overflow-hidden">
          <div className="mb-6 shrink-0">
            <h2 className="text-2xl font-bold mb-4">{t('marketplace_restaurant')}</h2>
            {/* Categories */}
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
              {MENU_CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={cn(
                    "px-6 py-3 rounded-2xl font-bold text-sm whitespace-nowrap transition-all active:scale-95",
                    activeCategory === cat 
                      ? "bg-primary text-primary-foreground shadow-md" 
                      : "bg-card border border-border hover:bg-muted text-foreground"
                  )}
                >
                  {t(cat.toLowerCase())}
                </button>
              ))}
            </div>
          </div>

          {/* Items Grid */}
          <div className="flex-1 overflow-y-auto pb-4">
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {menuItems[activeCategory].map(item => {
                // Link to inventory for stock level
                const stockItem = inventoryItems.find(i => i.name === item.name);
                const isLowStock = stockItem && stockItem.stock <= stockItem.minStock;
                
                return (
                  <button
                    key={item.id}
                    onClick={() => addToCart(item)}
                    disabled={stockItem && stockItem.stock === 0}
                    className={cn(
                      "card p-4 flex flex-col items-center justify-center text-center gap-2 hover:border-emerald-500/50 hover:shadow-lg transition-all active:scale-95 h-40 relative overflow-hidden",
                      stockItem && stockItem.stock === 0 && "opacity-50 grayscale cursor-not-allowed"
                    )}
                  >
                    <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-500 mb-1">
                      {item.icon}
                    </div>
                    <span className="font-bold text-sm leading-tight">{t(item.name.toLowerCase().replace(/\s+/g, '_'))}</span>
                    <span className="text-emerald-600 font-black">${item.price.toFixed(2)}</span>
                    
                    {stockItem && (
                      <div className={cn(
                        "mt-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-tighter",
                        isLowStock ? "bg-red-500 text-white" : "bg-muted text-muted-foreground"
                      )}>
                        {t('stock')}: {stockItem.stock}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Cart Section */}
        <div className="w-full lg:w-96 bg-card border-l border-border flex flex-col h-full shrink-0 shadow-2xl z-10">
          <div className="p-5 border-b border-border bg-muted/30">
            <h3 className="font-bold text-xl">{t('current_bill')}</h3>
            <p className="text-sm text-muted-foreground mt-1">{t('table')} 12 • {t('walk_in_guest')}</p>
          </div>

          <div className="flex-1 overflow-y-auto p-5 space-y-3">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50">
                <UtensilsCrossed size={48} className="mb-4" />
                <p className="font-medium">{t('no_items')}</p>
              </div>
            ) : (
              cart.map(item => (
                <div key={item.id} className="flex items-center justify-between bg-background p-3 rounded-xl border border-border">
                  <div className="flex-1">
                    <p className="font-bold text-sm">{t(item.name.toLowerCase().replace(/\s+/g, '_'))}</p>
                    <p className="text-emerald-600 font-bold text-sm">${item.price.toFixed(2)}</p>
                  </div>
                  <div className="flex items-center gap-3 bg-muted rounded-lg p-1">
                    <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-background hover:shadow-sm transition-all active:scale-90">
                      {item.quantity === 1 ? <Trash2 size={14} className="text-red-500" /> : <Minus size={14} />}
                    </button>
                    <span className="font-bold w-4 text-center text-sm">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-background hover:shadow-sm transition-all active:scale-90">
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="p-5 border-t border-border bg-muted/30 space-y-4">
            <div className="space-y-2 text-sm font-medium">
              <div className="flex justify-between"><span className="opacity-70">{t('subtotal')}</span><span>${subtotal.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="opacity-70">{t('tax')} (10%)</span><span>${tax.toFixed(2)}</span></div>
              <div className="flex justify-between text-xl font-black pt-2 border-t border-border mt-2">
                <span>{t('total')}</span>
                <span className="text-emerald-600">${total.toFixed(2)}</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button 
                disabled={cart.length === 0}
                className="py-3 rounded-xl font-bold text-sm bg-indigo-500 text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-600 active:scale-95 transition-all disabled:opacity-50 disabled:active:scale-100"
              >
                {t('room_charge')}
              </button>
              <button 
                onClick={handleOrder}
                disabled={cart.length === 0}
                className="py-3 rounded-xl font-bold text-sm bg-emerald-500 text-white shadow-lg shadow-emerald-500/20 hover:bg-emerald-600 active:scale-95 transition-all disabled:opacity-50 disabled:active:scale-100"
              >
                {t('pay')}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Stats Area for Restaurant */}
      <div className="h-64 border-t border-border bg-card p-6 flex gap-6 shrink-0 overflow-x-auto">
        <div className="w-64 shrink-0 bg-emerald-500/10 rounded-2xl p-6 flex flex-col justify-center border border-emerald-500/20">
          <h4 className="text-emerald-700 dark:text-emerald-400 font-bold mb-2">{t('revenue_today')}</h4>
          <p className="text-4xl font-black text-emerald-600 dark:text-emerald-500">$3,050</p>
          <p className="text-sm font-medium text-emerald-600/70 mt-2">+15% {t('vs_yesterday')}</p>
        </div>
        
        <div className="flex-1 min-w-[400px] bg-background rounded-2xl border border-border p-4 flex flex-col">
          <h4 className="font-bold text-sm mb-4">{t('sales_by_category')}</h4>
          <div className="flex-1">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={RESTAURANT_STATS} layout="vertical" margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={60} tick={{ fontSize: 12, fontWeight: 'bold' }} tickFormatter={(value) => t(value.toLowerCase())} />
                <Tooltip cursor={{ fill: 'var(--muted)' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} labelFormatter={(label) => t(label.toLowerCase())} />
                <Bar dataKey="sales" fill="#10b981" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

function LeisureView() {
  const { t } = useTranslation();
  const [cart, setCart] = useState<any[]>([]);

  const addToCart = (item: any) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQ = item.quantity + delta;
        return newQ > 0 ? { ...item, quantity: newQ } : item;
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.1; // 10% tax
  const total = subtotal + tax;

  return (
    <div className="flex flex-col lg:flex-row h-full overflow-hidden">
      {/* Services Section */}
      <div className="flex-1 p-8 flex flex-col overflow-hidden">
        <div className="mb-8 shrink-0">
          <h2 className="text-2xl font-bold mb-2">{t('leisure_services')}</h2>
          <p className="text-muted-foreground">{t('leisure_services_desc')}</p>
        </div>

        {/* Items Grid */}
        <div className="flex-1 overflow-y-auto pb-8">
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
            {LEISURE_ITEMS.map(item => (
              <button
                key={item.id}
                onClick={() => addToCart(item)}
                className="card p-4 flex flex-col items-center justify-center text-center gap-3 hover:border-primary/50 hover:shadow-lg transition-all active:scale-95 h-40"
              >
                <div className="w-12 h-12 rounded-full bg-sky-500/10 flex items-center justify-center text-sky-500 mb-2">
                  {item.icon}
                </div>
                <span className="font-bold text-sm leading-tight">{t(item.name.toLowerCase().replace(/\s+/g, '_'))}</span>
                <span className="text-sky-500 font-black">${item.price.toFixed(2)}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cart Section */}
      <div className="w-full lg:w-96 bg-card border-l border-border flex flex-col h-full shrink-0 shadow-2xl z-10">
        <div className="p-6 border-b border-border bg-muted/30">
          <h3 className="font-bold text-xl">{t('current_booking')}</h3>
          <p className="text-sm text-muted-foreground mt-1">{t('walk_in_guest')}</p>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50">
              <Waves size={48} className="mb-4" />
              <p className="font-medium">{t('no_services_selected')}</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.id} className="flex items-center justify-between bg-background p-3 rounded-xl border border-border">
                <div className="flex-1">
                  <p className="font-bold text-sm">{t(item.name.toLowerCase().replace(/\s+/g, '_'))}</p>
                  <p className="text-sky-500 font-bold text-sm">${item.price.toFixed(2)}</p>
                </div>
                <div className="flex items-center gap-3 bg-muted rounded-lg p-1">
                  <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-background hover:shadow-sm transition-all active:scale-90">
                    {item.quantity === 1 ? <Trash2 size={14} className="text-red-500" /> : <Minus size={14} />}
                  </button>
                  <span className="font-bold w-4 text-center text-sm">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-background hover:shadow-sm transition-all active:scale-90">
                    <Plus size={14} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-6 border-t border-border bg-muted/30 space-y-4">
          <div className="space-y-2 text-sm font-medium">
            <div className="flex justify-between"><span className="opacity-70">{t('subtotal')}</span><span>${subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="opacity-70">{t('tax')} (10%)</span><span>${tax.toFixed(2)}</span></div>
            <div className="flex justify-between text-xl font-black pt-2 border-t border-border mt-2">
              <span>{t('total')}</span>
              <span className="text-sky-500">${total.toFixed(2)}</span>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3 pt-4">
            <button 
              disabled={cart.length === 0}
              className="py-4 rounded-xl font-bold text-sm bg-indigo-500 text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-600 active:scale-95 transition-all disabled:opacity-50 disabled:active:scale-100"
            >
              {t('charge_room')}
            </button>
            <button 
              disabled={cart.length === 0}
              className="py-4 rounded-xl font-bold text-sm bg-sky-500 text-white shadow-lg shadow-sky-500/20 hover:bg-sky-600 active:scale-95 transition-all disabled:opacity-50 disabled:active:scale-100"
            >
              {t('pay_now')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function InventoryView({ items, setItems, menuItems, setMenuItems }: { 
  items: any[], 
  setItems: React.Dispatch<React.SetStateAction<any[]>>,
  menuItems: Record<string, any[]>,
  setMenuItems: React.Dispatch<React.SetStateAction<Record<string, any[]>>>
}) {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'All' || item.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const updateStock = (id: string, newStock: number) => {
    setItems(prev => prev.map(item => {
      if (item.id === id) {
        const status = newStock <= item.minStock ? (newStock <= 5 ? 'Critical' : 'Low') : 'Good';
        return { ...item, stock: newStock, status };
      }
      return item;
    }));
  };

  return (
    <div className="p-8 h-full flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold">{t('inventory_management')}</h2>
          <p className="text-muted-foreground mt-1">{t('inventory_desc')}</p>
        </div>
        <button className="flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-xl font-bold text-sm hover:opacity-90 transition-opacity active:scale-95 shadow-md">
          <Plus size={18} />
          {t('add_item')}
        </button>
      </div>

      <div className="card flex-1 overflow-hidden flex flex-col">
        <div className="p-4 border-b border-border bg-muted/30 flex gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <input 
              type="text" 
              placeholder={t('search_inventory')} 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-background border border-border rounded-lg py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-primary/20 transition-all outline-none"
            />
          </div>
          <select 
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-background border border-border rounded-lg text-sm font-semibold px-4 py-2 outline-none cursor-pointer"
          >
            <option value="All">{t('all_categories')}</option>
            {MENU_CATEGORIES.map(cat => <option key={cat} value={cat}>{t(cat.toLowerCase())}</option>)}
            <option value="Hotel">{t('hotel')}</option>
            <option value="Leisure">{t('leisure')}</option>
          </select>
        </div>
        
        <div className="flex-1 overflow-y-auto p-0">
          <table className="w-full">
            <thead className="bg-muted/50 sticky top-0 z-10 backdrop-blur-sm">
              <tr className="text-left text-xs uppercase tracking-wider opacity-70 border-b border-border">
                <th className="p-4 font-semibold">{t('item_name')}</th>
                <th className="p-4 font-semibold">{t('category')}</th>
                <th className="p-4 font-semibold">{t('stock_level')}</th>
                <th className="p-4 font-semibold">{t('status')}</th>
                <th className="p-4 font-semibold text-right">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filteredItems.map((item) => (
                <tr key={item.id} className="text-sm hover:bg-muted/30 transition-colors">
                  <td className="p-4 font-bold">{t(item.name.toLowerCase().replace(/\s+/g, '_'))}</td>
                  <td className="p-4 text-muted-foreground">{t(item.category.toLowerCase())}</td>
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <button onClick={() => updateStock(item.id, Math.max(0, item.stock - 1))} className="p-1 hover:bg-muted rounded"><Minus size={14}/></button>
                      <span className="font-mono font-bold w-8 text-center">{item.stock}</span>
                      <button onClick={() => updateStock(item.id, item.stock + 1)} className="p-1 hover:bg-muted rounded"><Plus size={14}/></button>
                      <span className="text-xs opacity-50">/ min {item.minStock}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-bold uppercase",
                      item.status === 'Critical' ? "bg-red-500/10 text-red-500" :
                      item.status === 'Low' ? "bg-amber-500/10 text-amber-500" :
                      "bg-emerald-500/10 text-emerald-500"
                    )}>
                      {t(item.status.toLowerCase())}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button className="text-sm font-bold text-primary hover:underline px-3 py-1.5 rounded-lg hover:bg-primary/5 transition-colors active:scale-95">
                      {t('reorder')}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function SettingsView({ logoUrl, setLogoUrl }: { logoUrl: string, setLogoUrl: (url: string) => void }) {
  const { t } = useTranslation();
  const [tempLogoUrl, setTempLogoUrl] = useState(logoUrl);

  return (
    <div className="p-8 h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h2 className="text-2xl font-bold">{t('settings')}</h2>
          <p className="text-muted-foreground mt-1">{t('settings_desc')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* General Settings */}
          <div className="card p-6 space-y-6">
            <h3 className="font-bold text-lg border-b border-border pb-4">{t('hotel_details')}</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-2 opacity-80">{t('hotel_name')}</label>
                <input type="text" defaultValue="POS" className="w-full bg-muted border border-border rounded-xl py-2.5 px-4 text-sm focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2 opacity-80">{t('logo_url')}</label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={tempLogoUrl} 
                    onChange={(e) => setTempLogoUrl(e.target.value)}
                    className="flex-1 bg-muted border border-border rounded-xl py-2.5 px-4 text-sm focus:ring-2 focus:ring-primary/20 outline-none" 
                  />
                  <button 
                    onClick={() => setLogoUrl(tempLogoUrl)}
                    className="bg-primary text-primary-foreground px-4 rounded-xl font-bold text-xs"
                  >
                    {t('apply')}
                  </button>
                </div>
              </div>
              <div className="w-20 h-20 bg-muted rounded-xl overflow-hidden border border-border flex items-center justify-center">
                <img src={logoUrl} alt="Preview" className="w-full h-full object-contain p-2" referrerPolicy="no-referrer" />
              </div>
            </div>
          </div>

          {/* Billing & Tax */}
          <div className="card p-6 space-y-6">
            <h3 className="font-bold text-lg border-b border-border pb-4">{t('billing_config')}</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-2 opacity-80">{t('tax_rate')} (%)</label>
                <input type="number" defaultValue="10" className="w-full bg-muted border border-border rounded-xl py-2.5 px-4 text-sm focus:ring-2 focus:ring-primary/20 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2 opacity-80">{t('currency')}</label>
                <select className="w-full bg-muted border border-border rounded-xl py-2.5 px-4 text-sm focus:ring-2 focus:ring-primary/20 outline-none">
                  <option>USD ($)</option>
                  <option>EUR (€)</option>
                  <option>CDF (FC)</option>
                </select>
              </div>
            </div>
          </div>

          {/* System Status */}
          <div className="md:col-span-2 card p-6 space-y-6 bg-muted/20">
            <h3 className="font-bold text-lg border-b border-border pb-4">{t('software_status')}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <StatusCard label={t('version')} value="v2.4.0-stable" />
              <StatusCard label={t('database')} value={t('cloud_synced')} />
              <StatusCard label={t('last_sync')} value={t('minutes_ago', { count: 2 })} />
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <button className="bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold shadow-lg hover:opacity-90 active:scale-95 transition-all">
            {t('apply')}
          </button>
        </div>
      </div>
    </div>
  );
}

// --- COMPONENTS ---

function LanguageSelector() {
  const { i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);

  const languages = [
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'zh', name: '中文', flag: '🇨🇳' },
    { code: 'ar', name: 'العربية', flag: '🇦🇪' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
  ];

  const currentLang = languages.find(l => l.code === i18n.language) || languages[0];

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-xl bg-muted border border-border hover:bg-border transition-all active:scale-95"
      >
        <span className="text-lg leading-none">{currentLang.flag}</span>
        <span className="text-xs font-black">{currentLang.name}</span>
        <ChevronDown size={14} className={cn("transition-transform opacity-50", isOpen && "rotate-180")} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
            <motion.div 
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="absolute right-0 mt-2 w-48 bg-card border border-border rounded-2xl shadow-2xl z-50 overflow-hidden p-2"
            >
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => changeLanguage(lang.code)}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition-colors",
                    i18n.language === lang.code 
                      ? 'bg-primary text-primary-foreground' 
                      : 'hover:bg-muted'
                  )}
                >
                  <span className="text-xl leading-none">{lang.flag}</span>
                  <span>{lang.name}</span>
                </button>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function KitchenView({ orders, setOrders }: { orders: any[], setOrders: React.Dispatch<React.SetStateAction<any[]>> }) {
  const { t, i18n } = useTranslation();
  
  const updateStatus = (id: string, status: string) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
  };

  const completeOrder = (id: string) => {
    setOrders(prev => prev.filter(o => o.id !== id));
  };

  const readOrder = (order: any) => {
    if (typeof window === 'undefined' || !('SpeechSynthesisUtterance' in window)) return;
    
    const text = t('order_for_table', { table: order.table }) + '. ' + order.items.map((i: any) => `${i.quantity} ${i.name}`).join(', ');
    const utterance = new window.SpeechSynthesisUtterance(text);
    utterance.lang = i18n.language === 'fr' ? 'fr-FR' : 
                   i18n.language === 'en' ? 'en-US' : 
                   i18n.language === 'es' ? 'es-ES' : 
                   i18n.language === 'ar' ? 'ar-SA' : 'zh-CN';
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="p-8 h-full flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold">{t('kitchen_view')}</h2>
          <p className="text-muted-foreground mt-1">{t('kitchen_view_desc')}</p>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center gap-2 text-sm font-bold"><div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div> {t('pending')}</div>
          <div className="flex items-center gap-2 text-sm font-bold"><div className="w-3 h-3 rounded-full bg-blue-500"></div> {t('cooking')}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {orders.map(order => (
          <motion.div 
            layout
            key={order.id}
            className={cn(
              "card p-6 border-t-8 flex flex-col gap-4 shadow-lg",
              order.status === 'pending' ? "border-t-red-500" : "border-t-blue-500"
            )}
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-2xl font-black">{t('table')} {order.table}</h3>
                <p className="text-xs opacity-60 font-bold">{order.id} • {order.timestamp}</p>
              </div>
              <button 
                onClick={() => readOrder(order)}
                className="p-2 rounded-lg bg-muted hover:bg-border transition-colors text-primary active:scale-95"
              >
                <Volume2 size={20} />
              </button>
            </div>

            <div className="flex-1 space-y-2 py-4 border-y border-border/50">
              {order.items.map((item: any, idx: number) => (
                <div key={idx} className="flex justify-between items-center">
                  <span className="font-bold">{item.name}</span>
                  <span className="bg-muted px-2 py-1 rounded-lg text-xs font-black">x{item.quantity}</span>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              {order.status === 'pending' ? (
                <button 
                  onClick={() => updateStatus(order.id, 'cooking')}
                  className="flex-1 py-3 bg-blue-500 text-white rounded-xl font-bold text-sm active:scale-95 transition-all"
                >
                  {t('prepare')}
                </button>
              ) : (
                <button 
                  onClick={() => completeOrder(order.id)}
                  className="flex-1 py-3 bg-emerald-500 text-white rounded-xl font-bold text-sm active:scale-95 transition-all"
                >
                  {t('finish')}
                </button>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function StatCard({ title, value, trend, icon, color }: { title: string, value: string, trend: string, icon: React.ReactNode, color: string }) {
  const isPositive = trend.startsWith('+');
  
  return (
    <div className="card p-6 relative overflow-hidden group hover:border-primary/30 transition-colors cursor-default">
      <div className={cn(
        "absolute top-0 right-0 w-32 h-32 -mr-12 -mt-12 rounded-full opacity-5 transition-transform duration-500 group-hover:scale-150",
        `bg-${color}-500`
      )} />
      
      <div className="flex items-center justify-between mb-6">
        <div className={cn(
          "w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm",
          color === 'indigo' ? "bg-indigo-500/10 text-indigo-500" :
          color === 'emerald' ? "bg-emerald-500/10 text-emerald-500" :
          color === 'amber' ? "bg-amber-500/10 text-amber-500" :
          "bg-sky-500/10 text-sky-500"
        )}>
          {icon}
        </div>
        <span className={cn(
          "text-xs font-bold px-3 py-1.5 rounded-lg",
          isPositive ? "bg-emerald-500/10 text-emerald-500" : "bg-red-500/10 text-red-500"
        )}>
          {trend}
        </span>
      </div>
      
      <p className="text-sm opacity-60 font-semibold">{title}</p>
      <h4 className="text-3xl font-black mt-1 tracking-tight">{value}</h4>
    </div>
  );
}
